﻿# ModularAvatarPrefabs Sample

This sample demonstrates the usage of lilToon PCSS Extension v1.2.0.

## Installation

1. Import this sample through Unity Package Manager
2. Follow the setup instructions in the main documentation

## Contents

- Sample materials and prefabs
- Configuration examples
- Best practice demonstrations

For detailed documentation, visit: https://github.com/zapabob/liltoon-pcss-extension
