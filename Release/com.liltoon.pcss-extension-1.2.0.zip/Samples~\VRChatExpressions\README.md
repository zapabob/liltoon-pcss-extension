﻿# VRChatExpressions

Pre-configured VRChat Expression Menu and Parameters

## Installation

1. Open VCC (VRChat Creator Companion)
2. Add this package to your project
3. Import this sample from the Package Manager
4. Follow the setup instructions in the main README

## Support

For support and documentation, visit:
https://github.com/zapabob/liltoon-pcss-extension
