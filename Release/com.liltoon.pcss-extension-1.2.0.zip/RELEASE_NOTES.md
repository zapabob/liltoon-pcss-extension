﻿# lilToon PCSS Extension v1.2.0 Release Notes

## 脂 譁ｰ讖溯・

### VCC (VRChat Creator Companion) 螳悟・蟇ｾ蠢・
- 繝ｯ繝ｳ繧ｯ繝ｪ繝・け繧､繝ｳ繧ｹ繝医・繝ｫ蟇ｾ蠢・
- 閾ｪ蜍穂ｾ晏ｭ倬未菫りｧ｣豎ｺ
- VPM繝ｪ繝昴ず繝医Μ蟇ｾ蠢・

### VRC Light Volumes邨ｱ蜷・
- 谺｡荳紋ｻ｣繝懊け繧ｻ繝ｫ繝ｩ繧､繝・ぅ繝ｳ繧ｰ繧ｷ繧ｹ繝・Β蟇ｾ蠢・
- 繝ｪ繧｢繝ｫ繧ｿ繧､繝蜈画ｺ占ｿｽ霍｡
- 繝代ヵ繧ｩ繝ｼ繝槭Φ繧ｹ譛驕ｩ蛹・

### ModularAvatar邨ｱ蜷亥ｼｷ蛹・
- 閾ｪ蜍輔お繧ｯ繧ｹ繝励Ξ繝・す繝ｧ繝ｳ險ｭ螳・
- 繝励Ξ繝上ヶ繝吶・繧ｹ縺ｮ邁｡蜊伜ｰ主・
- 髱樒ｴ螢顔噪繧｢繝舌ち繝ｼ謾ｹ螟・

## 肌 謾ｹ蝟・せ

### 繝代ヵ繧ｩ繝ｼ繝槭Φ繧ｹ譛驕ｩ蛹・
- VRChat蜩∬ｳｪ險ｭ螳夐｣蜍・
- Quest蟇ｾ蠢懷ｼｷ蛹・
- 繝｡繝｢繝ｪ菴ｿ逕ｨ驥丞炎貂・

### 繝ｦ繝ｼ繧ｶ繝薙Μ繝・ぅ蜷台ｸ・
- 繧ｻ繝・ヨ繧｢繝・・繧ｦ繧｣繧ｶ繝ｼ繝芽ｿｽ蜉
- 繧ｨ繝ｩ繝ｼ繝上Φ繝峨Μ繝ｳ繧ｰ蠑ｷ蛹・
- 隧ｳ邏ｰ繝峨く繝･繝｡繝ｳ繝域紛蛯・

## 菅 繝舌げ菫ｮ豁｣

- 繧ｷ繧ｧ繝ｼ繝繝ｼ繧ｳ繝ｳ繝代う繝ｫ繧ｨ繝ｩ繝ｼ菫ｮ豁｣
- Quest迺ｰ蠅・〒縺ｮ螳牙ｮ壽ｧ蜷台ｸ・
- 繝｡繝｢繝ｪ繝ｪ繝ｼ繧ｯ蝠城｡瑚ｧ｣豎ｺ

## 答 繝峨く繝･繝｡繝ｳ繝・

- VCC蟆主・繧ｬ繧､繝芽ｿｽ蜉
- 繝医Λ繝悶Ν繧ｷ繝･繝ｼ繝・ぅ繝ｳ繧ｰ蠑ｷ蛹・
- API 繝ｪ繝輔ぃ繝ｬ繝ｳ繧ｹ譖ｴ譁ｰ

## 迫 繝ｪ繝ｳ繧ｯ

- GitHub: https://github.com/zapabob/liltoon-pcss-extension
- VPM Repository: https://zapabob.github.io/liltoon-pcss-extension/
- Documentation: https://github.com/zapabob/liltoon-pcss-extension/blob/main/README.md

---
**Release Date**: 2025-06-21
**Build**: Automated Release Build
